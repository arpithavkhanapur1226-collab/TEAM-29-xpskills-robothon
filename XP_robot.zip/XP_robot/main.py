import cv2
import mediapipe as mp
import mujoco
import mujoco.viewer
import numpy as np
import time

XML_PATH = "humanoid.xml"

# joints
L_HIP, L_KNEE, L_ANKLE = 0,1,2
R_HIP, R_KNEE, R_ANKLE = 3,4,5
L_SH, R_SH = 6,7
L_EL, R_EL = 8,9

XML_PATH = "humanoid.xml"
model = mujoco.MjModel.from_xml_path(XML_PATH)

mujoco.mj_resetData(model, data)

# ===== LOCK BODY IN AIR (NO FALL) =====
data.qpos[:] = 0
data.qpos[2] = 1.2
data.qpos[3:7] = [1,0,0,0]

mp_pose = mp.solutions.pose
pose = mp_pose.Pose()
mp_draw = mp.solutions.drawing_utils

cap = cv2.VideoCapture(0)

def angle(a,b,c):
    a=np.array(a[:2]); b=np.array(b[:2]); c=np.array(c[:2])
    ba=a-b; bc=c-b
    cos=np.dot(ba,bc)/(np.linalg.norm(ba)*np.linalg.norm(bc)+1e-8)
    return np.degrees(np.arccos(np.clip(cos,-1,1)))

start = time.time()

with mujoco.viewer.launch_passive(model,data) as viewer:

    viewer.cam.lookat=[0,0,1]
    viewer.cam.distance=3
    viewer.cam.azimuth=90
    viewer.cam.elevation=-15

    while cap.isOpened():

        ret,frame = cap.read()
        if not ret:
            break

        frame=cv2.flip(frame,1)
        rgb=cv2.cvtColor(frame,cv2.COLOR_BGR2RGB)
        res=pose.process(rgb)

        t=time.time()-start

        # ===== FREEZE BODY (IMPORTANT) =====
        data.qpos[0] = 0
        data.qpos[1] = 0
        data.qpos[2] = 1.2

        data.qvel[:] = 0  # now OK because we are locking robot

        # ===== FIX LEGS (NO FALL) =====
        data.ctrl[L_HIP] = 0
        data.ctrl[R_HIP] = 0

        data.ctrl[L_KNEE] = 0.3
        data.ctrl[R_KNEE] = 0.3

        data.ctrl[L_ANKLE] = -0.2
        data.ctrl[R_ANKLE] = -0.2

        # ===== DEFAULT WAVE =====
        data.ctrl[R_SH] = np.sin(t*3)*0.3
        data.ctrl[R_EL] = np.sin(t*3)*0.3

        # ===== MEDIAPIPE =====
        if res.pose_landmarks:
            lm = res.pose_landmarks.landmark

            mp_draw.draw_landmarks(frame,res.pose_landmarks,mp_pose.POSE_CONNECTIONS)

            ls,le,lw = lm[11],lm[13],lm[15]
            rs,re,rw = lm[12],lm[14],lm[16]

            try:
                shL=angle([ls.x,ls.y],[le.x,le.y],[lw.x,lw.y])
                elL=angle([le.x,le.y],[lw.x,lw.y],[ls.x,ls.y])

                shR=angle([rs.x,rs.y],[re.x,re.y],[rw.x,rw.y])
                elR=angle([re.x,re.y],[rw.x,rw.y],[rs.x,rs.y])

                data.ctrl[L_SH] = (shL-90)*0.01
                data.ctrl[L_EL] = (elL-90)*0.01

                data.ctrl[R_SH] = (shR-90)*0.01
                data.ctrl[R_EL] = (elR-90)*0.01

            except:
                pass

        mujoco.mj_step(model,data)
        viewer.sync()

        cv2.imshow("Pose",frame)
        if cv2.waitKey(1)==27:
            break

cap.release()
cv2.destroyAllWindows()
