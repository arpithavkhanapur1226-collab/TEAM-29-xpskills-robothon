import cv2
import mediapipe as mp
import mujoco
import mujoco.viewer
import numpy as np
from collections import deque

# ================= CONFIG =================
XML_PATH = "XP_robot_with_limits.xml"

Kp = 100.0   # strong hold
Kd = 10.0

LEFT_SHOULDER_IDX  = 6
RIGHT_SHOULDER_IDX = 7
LEFT_ELBOW_IDX     = 8
RIGHT_ELBOW_IDX    = 9

# ================= LOAD MODEL =================
model = mujoco.MjModel.from_xml_path(XML_PATH)
data  = mujoco.MjData(model)

model.dof_damping[:] = 20.0  # VERY IMPORTANT

mujoco.mj_resetData(model, data)

# force upright
data.qpos[:] = 0
data.qpos[2] = 1.2

# ================= MEDIAPIPE =================
mp_pose = mp.solutions.pose
pose = mp_pose.Pose()
mp_draw = mp.solutions.drawing_utils

cap = cv2.VideoCapture(0)

# ================= SMOOTHER =================
class Smoother:
    def __init__(self):
        self.buf = {i: deque(maxlen=5) for i in range(33)}

    def update(self, lms):
        for i, lm in enumerate(lms):
            self.buf[i].append((lm.x, lm.y, lm.z))

    def get(self, i):
        if not self.buf[i]:
            return None
        return np.mean(self.buf[i], axis=0)

smooth = Smoother()

# ================= ANGLE =================
def angle_between(a, b, c):
    a = np.array(a[:2])
    b = np.array(b[:2])
    c = np.array(c[:2])

    ba = a - b
    bc = c - b

    cos = np.dot(ba, bc) / (np.linalg.norm(ba)*np.linalg.norm(bc) + 1e-8)
    return np.degrees(np.arccos(np.clip(cos, -1, 1)))

# ================= CONTROL =================
def pd(i, target):
    joint = model.actuator_trnid[i, 0]
    qpos_i = model.jnt_qposadr[joint]
    qvel_i = model.jnt_dofadr[joint]

    pos = data.qpos[qpos_i]
    vel = data.qvel[qvel_i]

    return Kp*(target-pos) - Kd*vel

def write(i, val):
    if i < 0 or i >= model.nu:
        return
    data.ctrl[i] = np.clip(val, -300, 300)

# ================= MAIN =================
with mujoco.viewer.launch_passive(model, data) as viewer:
    while cap.isOpened():

        ret, frame = cap.read()
        if not ret:
            break

        frame = cv2.flip(frame, 1)
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        res = pose.process(rgb)

        # ================= STRONG STANDING POSE =================
        target = np.zeros(model.nu)

        # HARD LOCK ALL LOWER BODY
        for i in range(6):
            target[i] = 0.0

        # slight knee bend
        target[2] = 0.4
        target[5] = 0.4

        # ================= POSE =================
        if res.pose_landmarks:
            lm_raw = res.pose_landmarks.landmark
            smooth.update(lm_raw)

            mp_draw.draw_landmarks(frame, res.pose_landmarks, mp_pose.POSE_CONNECTIONS)

            def lm(i): return smooth.get(i)

            # LEFT ARM
            ls, le, lw = lm(11), lm(13), lm(15)
            if ls is not None and le is not None and lw is not None:
                sh = angle_between(ls, le, lw)
                write(LEFT_SHOULDER_IDX, pd(LEFT_SHOULDER_IDX, np.radians(sh-90)*0.3))

            # RIGHT ARM
            rs, re, rw = lm(12), lm(14), lm(16)
            if rs is not None and re is not None and rw is not None:
                sh = angle_between(rs, re, rw)
                write(RIGHT_SHOULDER_IDX, pd(RIGHT_SHOULDER_IDX, np.radians(sh-90)*0.3))

        # ================= APPLY =================
        for i in range(model.nu):
            write(i, pd(i, target[i]))

        mujoco.mj_step(model, data)
        viewer.sync()

        cv2.imshow("Pose", frame)
        if cv2.waitKey(1) == 27:
            break

cap.release()
cv2.destroyAllWindows() where should i run give path
